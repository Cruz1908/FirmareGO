<?php
/**
 * Configuración de base de datos MySQL
 * Generado automáticamente por install.php
 */

// Si no existe, usar valores por defecto para XAMPP
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'frimango');
    define('DB_CHARSET', 'utf8mb4');
}
