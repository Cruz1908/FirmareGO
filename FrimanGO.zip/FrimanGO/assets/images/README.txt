Coloca aquí las imágenes de diseño para replicar la Landing y versión móvil.

Sugeridas (puedes renombrar si prefieres):
- landing-hero.jpg  (hero principal)
- navbar-bg.jpg     (fondo opcional de navbar)
- category-*.jpg    (banners de categorías)

Una vez copiadas, recarga: http://localhost:8000/